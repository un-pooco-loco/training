import { Component } from '@angular/core';

@Component({
  selector: 'hp-app-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
