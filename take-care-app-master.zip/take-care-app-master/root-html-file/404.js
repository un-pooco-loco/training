const errorpage = '<div class="anim-box">'+
'    <div class="ghost">'+
'        <div class="ghost-container">'+
'            <div class="ghost-eyes">'+
'                <div class="eye-left">4</div>'+
'                <div class="eye-right">4</div>'+
'            </div>'+
'            <div class="ghost-mouth">O</div>'+
'        </div>'+
'        <div class="ghost-shadow"></div>'+
'    </div>'+
''+
'    <div class="not-found-description">'+
'        <div class="not-found-description-container">'+
'            <div class="not-found-description-title">Whoops!</div>'+
'            <div class="not-found-description-text">We could not find a single soul on this page.</div>'+
'        </div>'+
''+
'        <div class="not-found-description-message">Since the page is down, alternatively; you can:</div>'+
'        <a href="/" id="notFoundLink" class="not-found-button">Go back</a>'+
'        <a href="#" class="not-found-button report-text">Report</a>'+
'    </div>'+
'</div>';