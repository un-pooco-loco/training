import { Component } from '@angular/core';

@Component({
  selector: 'tc-app-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
