import { Component } from '@angular/core';

@Component({
  selector: 'ws-app-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
